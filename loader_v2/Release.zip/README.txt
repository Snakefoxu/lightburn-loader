LightBurn Custom Loader (for v2.0.05)
=====================================

Installation Instructions:
1. Copy "LightBurn_Loader.exe" into your LightBurn installation folder.
   (Usually: C:\Program Files\LightBurn)

2. Ensure "LightBurn.exe" is in that same folder.

3. ALWAYS run "LightBurn_Loader.exe" (or the shortcut) to start the program.
   (You can use install_shortcut.bat to create the shortcut for you).

Note: This loader relies on in-memory patching to enable functionality. It does not modify any original files on your disk.
