# Protocolo Omega: Guía de Parcheo LightBurn

> **NIVEL DE ACCESO: CLASIFICADO**
> Esta documentación detalla el proceso técnico para mantener el bypass de LightBurn operativo en futuras versiones.

## 1. Teoría de Operación
El loader (`LightBurn_Loader.exe`) funciona aplicando parches en memoria (RAM) al proceso de LightBurn una vez cargado, pero antes de que se ejecute su código principal.
Esto evita modificar el ejecutable en disco, eludiendo verificaciones de integridad estáticas.

### El Objetivo
LightBurn utiliza `LexActivator.dll` para la licencia, pero también tiene verificaciones internas en el propio ejecutable.
El parche actual modifica 4 puntos clave (Offsets/RVAs) para forzar saltos o anular comprobaciones.

```c
// Offsets actuales (v2.0.05)
DWORD64 TARGET_RVAS[] = {0x6522D5, 0x6522E1, 0x6522DB, 0x6522B7};
// Bytes de parche (XOR EAX, EAX; RET) - Básicamente "return 0" (Success)
const unsigned char PATCH_BYTES[] = {0x31, 0xC0, 0xC3};
```

## 2. Herramientas Necesarias
Todas las herramientas están en la carpeta `tools` del repositorio.
- **x64dbg:** Debugger para analizar el ejecutable en vivo.
- **Ghidra / IDA (Opcional):** Para análisis estático profundo.

## 3. Procedimiento de Actualización
Cuando salga una nueva versión de LightBurn (ej: 2.0.06), los offsets cambiarán. Sigue estos pasos para encontrarlos:

### Paso A: Identificar las Funciones a Parchear
Usando x64dbg:
1. Abre `LightBurn.exe` (Versión nueva) con x64dbg.
2. Ve a la pestaña **Symbols**.
3. Busca referencias a strings o llamadas a funciones relacionadas con "License", "Trial", o los mensajes de error que aparezcan.
4. *Truco:* Busca el patrón de bytes de las funciones parcheadas en la versión anterior. Aunque la dirección cambie, el código de la función suele ser similar.

### Paso B: Obtener los Nuevos RVAs
Una vez encuentres la instrucción donde se hace la validación (usualmente un `TEST EAX, EAX` seguido de `JZ/JNZ`):
1. Mira la dirección de memoria (ej: `0x7FF7406522D5`).
2. Mira la "Base Address" del módulo `LightBurn.exe` en la pestaña **Memory Map** (ej: `0x7FF740000000`).
3. Calcula el RVA: `Dirección - Base`
   - `0x7FF7406522D5 - 0x7FF740000000 = 0x6522D5`
4. Este `0x6522D5` es tu nuevo RVA.

### Paso C: Actualizar el Loader
1. Abre `dist\loader.c` (o `loader_debug.ps1`).
2. Actualiza el array `TARGET_RVAS` con los nuevos valores.
3. Recompila (si usas C) o simplemente corre el script (si usas PS).

## 4. Recompilación
Si modificas `loader.c`, usa el script `build.sh` (requiere entorno MinGW/GCC) o TCC si logramos configurarlo.
Para pruebas rápidas, usa siempre `loader_debug.ps1`.

---
*Protocolo Omega - Fin de Documento*
