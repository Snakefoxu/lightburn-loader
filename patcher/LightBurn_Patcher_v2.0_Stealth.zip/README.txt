LIGHTBURN PATCHER v2.0 (Stealth Edition)
========================================

Este patcher activará LightBurn modificando el ejecutable directamente.
Es la versión "Stealth" diseñada para no ser detectada por antivirus.

INSTRUCCIONES:
1. Copia todos los archivos de esta carpeta a la carpeta donde instalaste LightBurn.
   (Generalmente: C:\Program Files\LightBurn\)

2. Ejecuta "Run_Patcher.cmd" (Doble clic).
   - Acepta la ventana de Administrador si aparece.

3. El script automáticamente:
   - Hará un backup de tu LightBurn.exe original.
   - Aplicará el parche.
   - Verificará que todo esté correcto.

4. ¡Listo! Ya puedes abrir LightBurn normalmente.

NOTA:
Si quieres deshacer los cambios, el script te dará la opción de Restaurar (Undo) si lo vuelves a ejecutar.
