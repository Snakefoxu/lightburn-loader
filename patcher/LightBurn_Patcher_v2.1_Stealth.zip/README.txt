LIGHTBURN PATCHER v2.1 (Stealth Edition)
==========================================

Este pack incluye todo lo necesario para activar LightBurn.

CONTENIDO:
1. LightBurn_Patched.exe (Pre-parcheado, listo para usar)
2. patcher.ps1 + Run_Patcher.cmd (Herramientas para hacerlo tú mismo)

 OPCIÓN A: RÁPIDA (Reemplazar)
--------------------------------
1. Copia "LightBurn_Patched.exe" a la carpeta de instalación.
   (C:\Program Files\LightBurn\)
2. Renombra tu "LightBurn.exe" original a "LightBurn.bak" (por seguridad).
3. Renombra "LightBurn_Patched.exe" a "LightBurn.exe".
4. ¡Listo! Solo ejecuta LightBurn normalmente.

 OPCIÓN B: ELEGANTE (Parchear)
------------------------------
1. Copia todos los archivos a la carpeta de instalación.
2. Ejecuta "Run_Patcher.cmd".
3. El script modificará tu archivo original automáticamente y hará backup.

Nota: Ambos métodos son indetectables.
